# Comment démarrer ?

Pense à installer les dépendances avec la commande `npm install` avant de démarrer le projet.

## Installer Angular CLI

Pour installer Angular CLI, il suffit de lancer la commande `npm install -g @angular/cli` dans le terminal.
Cela te permettra d'installer Angular CLI en global sur ta machine et de pouvoir accéder aux raccourcis de commande (bien pratique, tu verras !).

## Démarrer le projet

Pour démarrer le projet, il suffit de lancer la commande `npm start` dans le terminal.
